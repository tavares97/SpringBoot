package com.spring.tutorial.service;

import com.spring.tutorial.DAO.PersonDAO;
import com.spring.tutorial.model.Person;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Service
public class PersonService {

    private final PersonDAO personDAO;

    @Autowired
    public PersonService(@Qualifier("fakeDao") PersonDAO personDAO) {
        this.personDAO = personDAO;
    }

    // POST SERVICE
    public int addPerson(Person person) {
        return personDAO.insertPerson(person);
    }

    // GET SERVICE
    public List<Person> getAll() {
        return personDAO.selectAll();
    }

    //
    public Optional<Person> getPersonById(UUID id) {
        return personDAO.selectPersonById(id);
    }

    // DELETE
    public int deletePerson(UUID id) {
        return personDAO.deletePersonById(id);
    }

    //UPDATE
    public int updatePerson(UUID id, Person newPerson) {
        return personDAO.updatePersonById(id, newPerson);
    }
}
