package com.spring.tutorial.DAO;

import com.spring.tutorial.model.Person;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

public interface PersonDAO {

    int insertPerson(UUID id , Person person);

    // POST
    default int insertPerson(Person person) {
        UUID id = UUID.randomUUID();
        return insertPerson(id, person);
    }

    //GET
    List<Person> selectAll();

    // A container object which may or may not contain a non-null value.
    Optional<Person> selectPersonById(UUID id);

    // DELETE BY ID
    int deletePersonById(UUID id);

    //UPDATE
    int updatePersonById(UUID id, Person person);
}
